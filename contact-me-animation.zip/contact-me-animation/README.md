# Contact Me Animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/tt0113243/pen/dzyGpM](https://codepen.io/tt0113243/pen/dzyGpM).

Based on a <a href="https://dribbble.com/shots/2723297-Contact-Me-UI-Animation">Dribbble</a> by <a href="https://dribbble.com/richox">Riccardo Cavallo</a>.

Click on the "Contact Me" button to see it in action.